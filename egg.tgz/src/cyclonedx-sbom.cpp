// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("cyclonedx sbom"); }
int main(){
  announce();
  return lionss_run_workload("cyclonedx-sbom");
}

# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(configure-defaults src/configure-defaults.cpp)
set_property(TARGET configure-defaults PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-defaults lionss pthread)

add_executable(p99-latency src/p99-latency.cpp)
set_property(TARGET p99-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(p99-latency lionss pthread)

add_executable(acceptance-tests src/acceptance-tests.cpp)
set_property(TARGET acceptance-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(acceptance-tests lionss pthread)

add_executable(lizard-complexity src/lizard-complexity.cpp)
set_property(TARGET lizard-complexity PROPERTY CXX_STANDARD 11)
target_link_libraries(lizard-complexity lionss pthread)

add_executable(android-ndk-r26 src/android-ndk-r26.cpp)
set_property(TARGET android-ndk-r26 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-ndk-r26 lionss pthread)

add_executable(idempotency-tests src/idempotency-tests.cpp)
set_property(TARGET idempotency-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(idempotency-tests lionss pthread)

add_executable(export-map-check src/export-map-check.cpp)
set_property(TARGET export-map-check PROPERTY CXX_STANDARD 11)
target_link_libraries(export-map-check lionss pthread)

add_executable(fuzz-corpus src/fuzz-corpus.cpp)
set_property(TARGET fuzz-corpus PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-corpus lionss pthread)

add_executable(gcc-12 src/gcc-12.cpp)
set_property(TARGET gcc-12 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-12 lionss pthread)

add_executable(ipc-bench src/ipc-bench.cpp)
set_property(TARGET ipc-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(ipc-bench lionss pthread)

add_executable(clang-latest src/clang-latest.cpp)
set_property(TARGET clang-latest PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-latest lionss pthread)

add_executable(mocked-tests src/mocked-tests.cpp)
set_property(TARGET mocked-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(mocked-tests lionss pthread)

add_executable(structure-aware-fuzz src/structure-aware-fuzz.cpp)
set_property(TARGET structure-aware-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(structure-aware-fuzz lionss pthread)

add_executable(linux-x86-64 src/linux-x86-64.cpp)
set_property(TARGET linux-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-x86-64 lionss pthread)

add_executable(package-rpm src/package-rpm.cpp)
set_property(TARGET package-rpm PROPERTY CXX_STANDARD 11)
target_link_libraries(package-rpm lionss pthread)

add_executable(build-release src/build-release.cpp)
set_property(TARGET build-release PROPERTY CXX_STANDARD 11)
target_link_libraries(build-release lionss pthread)

add_executable(android-x86-64 src/android-x86-64.cpp)
set_property(TARGET android-x86-64 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-x86-64 lionss pthread)

add_executable(portable-binary src/portable-binary.cpp)
set_property(TARGET portable-binary PROPERTY CXX_STANDARD 11)
target_link_libraries(portable-binary lionss pthread)

add_executable(build-debug src/build-debug.cpp)
set_property(TARGET build-debug PROPERTY CXX_STANDARD 11)
target_link_libraries(build-debug lionss pthread)

add_executable(maintainability-index src/maintainability-index.cpp)
set_property(TARGET maintainability-index PROPERTY CXX_STANDARD 11)
target_link_libraries(maintainability-index lionss pthread)

add_executable(ubsan src/ubsan.cpp)
set_property(TARGET ubsan PROPERTY CXX_STANDARD 11)
target_link_libraries(ubsan lionss pthread)

add_executable(google-benchmark src/google-benchmark.cpp)
set_property(TARGET google-benchmark PROPERTY CXX_STANDARD 11)
target_link_libraries(google-benchmark lionss pthread)

add_executable(cmake-config-export src/cmake-config-export.cpp)
set_property(TARGET cmake-config-export PROPERTY CXX_STANDARD 11)
target_link_libraries(cmake-config-export lionss pthread)

add_executable(build-no-exceptions src/build-no-exceptions.cpp)
set_property(TARGET build-no-exceptions PROPERTY CXX_STANDARD 11)
target_link_libraries(build-no-exceptions lionss pthread)

add_executable(clang-18 src/clang-18.cpp)
set_property(TARGET clang-18 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-18 lionss pthread)

add_executable(nvcc-build src/nvcc-build.cpp)
set_property(TARGET nvcc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nvcc-build lionss pthread)

add_executable(package-snap src/package-snap.cpp)
set_property(TARGET package-snap PROPERTY CXX_STANDARD 11)
target_link_libraries(package-snap lionss pthread)

add_executable(icx-build src/icx-build.cpp)
set_property(TARGET icx-build PROPERTY CXX_STANDARD 11)
target_link_libraries(icx-build lionss pthread)

add_executable(windows-x64 src/windows-x64.cpp)
set_property(TARGET windows-x64 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-x64 lionss pthread)

add_executable(cyclonedx-sbom src/cyclonedx-sbom.cpp)
set_property(TARGET cyclonedx-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(cyclonedx-sbom lionss pthread)


// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("mocked tests"); }
int main(){
  announce();
  return lionss_run_workload("mocked-tests");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("portable binary"); }
int main(){
  announce();
  return lionss_run_workload("portable-binary");
}

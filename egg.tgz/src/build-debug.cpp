// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("build debug\n", stdout);
  return lionss_run_workload("build-debug");
}

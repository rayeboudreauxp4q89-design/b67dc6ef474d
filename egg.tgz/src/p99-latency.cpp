// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "p99 latency");
  std::fflush(stdout);
  return lionss_run_workload("p99-latency");
}
